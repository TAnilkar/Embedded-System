#include <lpc214x.h>
#include <stdio.h>

// Function to initialize UART0 for serial communication
void UART0_Init(void) {
    PINSEL0 |= 0x00000005; // Enable UART0 pins (P0.0 as TXD0, P0.1 as RXD0)
    U0LCR = 0x83;          // 8-bit data, 1 stop bit, no parity, enable DLAB
    U0DLL = 97;            // Set baud rate to 9600 (assuming 15MHz PCLK)
    U0DLM = 0;
    U0LCR = 0x03;          // Disable DLAB
}

// Function to send a character via UART0
void UART0_SendChar(char c) {
    while (!(U0LSR & 0x20)); // Wait for THR to be empty
    U0THR = c;
}

// Function to send a string via UART0
void UART0_SendString(const char *str) {
    while (*str) {
        UART0_SendChar(*str++);
    }
}

// Function to initialize the RTC
void RTC_Init(void) {
    PREINT = 0x000001C8;    // Prescaler integer (for 15MHz PCLK)
    PREFRAC = 0x61C0;       // Prescaler fractional (for 1-second increment)
    CCR = 0x02;             // Reset and disable RTC
    SEC = 0;                // Set seconds to 0
    MIN = 0;                // Set minutes to 0
    HOUR = 12;              // Set hours to 12 (12-hour format)
    DOM = 1;                // Set day of month to 1
    MONTH = 1;              // Set month to January
    YEAR = 2025;            // Set year to 2025
    CCR = 0x01;             // Enable RTC
}

// Function to display the current time and date via UART0
void RTC_Display(void) {
    char buffer[64];
    sprintf(buffer, "Time: %02d:%02d:%02d\r\n", HOUR, MIN, SEC);
    UART0_SendString(buffer);
    sprintf(buffer, "Date: %02d-%02d-%04d\r\n", DOM, MONTH, YEAR);
    UART0_SendString(buffer);
}

// Simple delay function
void delay(void) {
    int i;
    for (i = 0; i < 10000000; i++) {
        // Empty loop for delay
    }
}

int main(void) {
    UART0_Init(); // Initialize UART0
    RTC_Init();   // Initialize RTC

    UART0_SendString("RTC Initialized\r\n");

    while (1) {
        RTC_Display();
        delay(); // Use the delay function
    }

    // return 0; // Removed the unreachable return statement
}
