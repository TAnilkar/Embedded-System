// lcd.c
#include "lcd.h"
#include <LPC214x.h>
#include "delay.h"
#include "defines.h"
#include <stdio.h>
void LCD_Init(void) {
    WRITEBYTE(IODIR0, LCD_DAT, 0xFF);
    WRITEBIT(IODIR0, RS, 1);
    WRITEBIT(IODIR0, RW, 1);
    WRITEBIT(IODIR0, EN, 1);

    delay_ms(15);
    LCD_Command(0x38); // 8-bit mode, 2-line display
    LCD_Command(0x0C); // Display ON, Cursor OFF
    LCD_Command(0x06); // Auto Increment
    LCD_Command(0x01); // Clear Display
    delay_ms(2);
}

void LCD_Command(uint8_t cmd) {
    IOCLR0 = (1 << RS) | (1 << RW);
    IOSET0 = cmd << LCD_DAT;
    IOSET0 = (1 << EN);
    IOCLR0 = (1 << EN);
    delay_ms(2);
}

void LCD_Data(uint8_t data) {
    IOSET0 = (1 << RS);
    IOCLR0 = (1 << RW);
    IOSET0 = data << LCD_DAT;
    IOSET0 = (1 << EN);
    IOCLR0 = (1 << EN);
    delay_ms(2);
}

void LCD_WriteString(const char *str) {
    while (*str) {
        LCD_Data(*str++);
    }
}

void LCD_WriteFloat(float value, int precision) {
    char buffer[20];
    snprintf(buffer, sizeof(buffer), "%.*f", precision, value);
    LCD_WriteString(buffer);
}

void LCD_Clear(void) {
    LCD_Command(0x01); // Clear display command
    delay_ms(2);       // Allow time for execution
}
