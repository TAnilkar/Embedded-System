// uart.c
#include "uart.h"
#include <LPC214x.h>
#include "delay.h"
#include <stdio.h>
void Init_UART(void) {
    PINSEL0 |= 0x5; // Configure P0.0 and P0.1 for UART
    U0LCR = 0x83;   // 8-bit, 1 stop bit, DLAB enabled
    U0DLL = DIVISOR & 0xFF;
    U0DLM = (DIVISOR >> 8) & 0xFF;
    U0LCR &= ~0x80; // Disable DLAB
    U0IER = 0x03;   // Enable UART interrupts
}

void UART_SendChar(char ch) {
    while (!(U0LSR & 0x20));
    U0THR = ch;
}

void UART_SendString(const char *str) {
    while (*str) {
        UART_SendChar(*str++);
    }
}

int UART_ReceiveString(char *buffer, int length) {
    int i = 0;
    while (i < length - 1) {
        while (!(U0LSR & 0x01));
        buffer[i] = U0RBR;
        if (buffer[i] == '\n' || buffer[i] == '\r') {
            break;
        }
        i++;
    }
    buffer[i] = '\0';
    return i > 0;
}

void UART_SendFloat(float value, int precision) {
    char temp[20];
    snprintf(temp, sizeof(temp), "%.*f", precision, value);
    UART_SendString(temp);
}
