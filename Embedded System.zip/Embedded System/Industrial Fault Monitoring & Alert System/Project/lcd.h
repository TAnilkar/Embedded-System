// lcd.h
#ifndef LCD_H
#define LCD_H

#include <stdint.h>

#define LCD_DAT 8
#define RS 16
#define RW 18
#define EN 17

void LCD_Init(void);
void LCD_Command(uint8_t cmd);
void LCD_Data(uint8_t data);
void LCD_WriteString(const char *str);
void LCD_WriteFloat(float value, int precision);

#endif
