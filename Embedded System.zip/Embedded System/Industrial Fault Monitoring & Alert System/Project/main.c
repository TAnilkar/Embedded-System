// main.c
#include <LPC214x.h>
#include "lcd.h"
#include "uart.h"
#include "spi.h"
#include "spi_eeprom.h"
#include "sensors.h"
#include "delay.h"
#include "defines.h"
#include "gpio.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#define BUZZER_PIN 10

void Init_Peripherals(void);
void Process_SMS(char *sms);

int main(void) {
    char received_sms[50] = {0};

    Init_Peripherals();
    LCD_WriteString("System Init");

    while (1) {
        float temperature = Sensor_ReadTemperature();
        int smoke_status = Sensor_ReadSmokeStatus();

        // Display sensor readings
        LCD_Clear();
        LCD_WriteString("Temp: ");
        LCD_WriteFloat(temperature, 2);
        LCD_WriteString("C\nSmoke: ");
        LCD_WriteString(smoke_status ? "Detected" : "Clear");

        // Check for threshold breach
        if (temperature > EEPROM_ReadTemperatureThreshold()) {
            GPIO_Set(BUZZER_PIN);
            UART_SendString("ALERT: Temp Exceeded\n");
        } else {
            GPIO_Clear(BUZZER_PIN);
        }

        if (UART_ReceiveString(received_sms, sizeof(received_sms))) {
            Process_SMS(received_sms);
        }

        delay_ms(1000);
    }
}

void Init_Peripherals(void) {
    Init_UART();
    Init_SPI();
    LCD_Init();
    Sensor_Init();

    GPIO_SetDirection(BUZZER_PIN, OUTPUT);
}

void Process_SMS(char *sms) {
    if (strncmp(sms, "SETT", 4) == 0) {
        float new_threshold = atof(&sms[4]);
        EEPROM_WriteTemperatureThreshold(new_threshold);
        UART_SendString("Threshold Updated\n");
    } else if (strncmp(sms, "INFO", 4) == 0) {
        float temperature = Sensor_ReadTemperature();
        int smoke_status = Sensor_ReadSmokeStatus();

        UART_SendString("Temp: ");
        UART_SendFloat(temperature, 2);
        UART_SendString("C, Smoke: ");
        UART_SendString(smoke_status ? "Detected\n" : "Clear\n");
    } else {
        UART_SendString("Invalid Command\n");
    }
}
