// sensors.h
#ifndef SENSORS_H
#define SENSORS_H

#include <stdint.h>

#define LM35_CHANNEL 1
#define MQ2_CHANNEL 2
#define SMOKE_THRESHOLD 0.5

void Sensor_Init(void);
float Sensor_ReadTemperature(void);
int Sensor_ReadSmokeStatus(void);

#endif
