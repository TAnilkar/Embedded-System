// uart.h
#ifndef UART_H
#define UART_H

#define FOSC 12000000
#define CCLK (5 * FOSC)
#define PCLK (CCLK / 4)
#define BAUD 9600
#define DIVISOR (PCLK / (16 * BAUD))

void Init_UART(void);
void UART_SendChar(char ch);
void UART_SendString(const char *str);
int UART_ReceiveString(char *buffer, int length);
void UART_SendFloat(float value, int precision);

#endif
