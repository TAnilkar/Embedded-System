// gpio.c
#include <LPC214x.h>
#include <stdint.h>
#define uint8_t
void GPIO_SetDirection(uint8_t pin, uint8_t direction) {
    if (direction) {
        IODIR0 |= (1 << pin);
    } else {
        IODIR0 &= ~(1 << pin);
    }
}

void GPIO_Set(uint8_t pin) {
    IOSET0 |= (1 << pin);
}

void GPIO_Clear(uint8_t pin) {
    IOCLR0 |= (1 << pin);
}
