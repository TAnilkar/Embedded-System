#include "delay.h"

void delay_ms(uint32_t ms) {
    volatile uint32_t i; // Declare loop variable
    for (i = 0; i < (12000 * ms); i++) {}
}
