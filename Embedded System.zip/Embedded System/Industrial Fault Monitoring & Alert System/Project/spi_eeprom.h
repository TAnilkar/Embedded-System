// spi_eeprom.h
#ifndef SPI_EEPROM_H
#define SPI_EEPROM_H
#define TEMP_THRESHOLD_ADDR 0x0000

void EEPROM_WriteTemperatureThreshold(float threshold);
float EEPROM_ReadTemperatureThreshold(void);


#endif
