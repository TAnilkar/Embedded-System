// gpio.h

#ifndef GPIO_H
#define GPIO_H

#include <stdint.h>   // for uint8_t

// Function prototypes
void GPIO_SetDirection(uint8_t pin, uint8_t direction);
void GPIO_Set(uint8_t pin);
void GPIO_Clear(uint8_t pin);

// Optional: You can also define INPUT and OUTPUT if you like
#ifndef INPUT
#define INPUT  0
#endif

#ifndef OUTPUT
#define OUTPUT 1
#endif

#endif // GPIO_H
