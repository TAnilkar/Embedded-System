// spi_eeprom.c
#include "spi_eeprom.h"
#include "spi.h"
#include "delay.h"

void EEPROM_WriteTemperatureThreshold(float threshold) {
    uint16_t addr = TEMP_THRESHOLD_ADDR;
    uint16_t data = (uint16_t)(threshold * 100);
    SPI_WriteEnable();
    SPI_WriteByte(addr >> 8);
    SPI_WriteByte(addr & 0xFF);
    SPI_WriteByte(data >> 8);
    SPI_WriteByte(data & 0xFF);
    SPI_WriteDisable();
    delay_ms(10);
}

float EEPROM_ReadTemperatureThreshold(void) {
    uint16_t addr = TEMP_THRESHOLD_ADDR;
    uint16_t high_byte, low_byte;

    SPI_WriteEnable();
    SPI_WriteByte(addr >> 8);
    SPI_WriteByte(addr & 0xFF);
    high_byte = SPI_ReadByte();
    low_byte = SPI_ReadByte();
    SPI_WriteDisable();
    return ((high_byte << 8) | low_byte) / 100.0;
}
