// sensors.c
#include "sensors.h"
#include "adc.h"
#include <LPC214x.h>

void Sensor_Init(void) {
    Init_ADC();
}

float Sensor_ReadTemperature(void) {
    return Read_ADC(LM35_CHANNEL) * 100.0; // Convert ADC value to temperature
}

int Sensor_ReadSmokeStatus(void) {
    return Read_ADC(MQ2_CHANNEL) > SMOKE_THRESHOLD;
}
