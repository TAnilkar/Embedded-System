// spi.h
#ifndef SPI_H
#define SPI_H

#include <stdint.h>

void Init_SPI(void);
void SPI_WriteEnable(void);
void SPI_WriteDisable(void);
void SPI_WriteByte(uint8_t byte);
uint8_t SPI_ReadByte(void);

#endif
