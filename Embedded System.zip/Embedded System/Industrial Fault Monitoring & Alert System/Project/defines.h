// defines.h
#ifndef DEFINES_H
#define DEFINES_H

// Bit manipulation macros
#define SETBIT(WORD, BITPOS)    ((WORD) |= (1 << (BITPOS)))
#define CLRBIT(WORD, BITPOS)    ((WORD) &= ~(1 << (BITPOS)))
#define CPLBIT(WORD, BITPOS)    ((WORD) ^= (1 << (BITPOS)))
#define READBIT(WORD, BITPOS)   (((WORD) >> (BITPOS)) & 1)

// Write operations
#define WRITEBYTE(WORD, BITPOS, BYTE) \
    ((WORD) = ((WORD) & ~(0xFF << (BITPOS))) | ((BYTE) << (BITPOS)))
#define READBYTE(WORD, BITPOS)  (((WORD) >> (BITPOS)) & 0xFF)

// Missing Macro
#define WRITEBIT(WORD, BITPOS, BIT) \
    ((WORD) = ((WORD & ~(1 << BITPOS)) | (BIT << BITPOS)))

// Common constants
#define OUTPUT 1
#define INPUT  0

#endif
