// adc.h
#ifndef ADC_H
#define ADC_H

#include <stdint.h>

void Init_ADC(void);
float Read_ADC(uint8_t channel);

#endif
