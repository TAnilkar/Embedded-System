#include "spi.h"
#include <LPC214x.h>
#define CS_PIN 10 // Example pin for Chip Select

void Init_SPI(void) {
    PINSEL0 |= (1 << 4) | (1 << 6); // Configure SPI pins
    S0SPCR = 0x20;                 // SPI control register
    S0SPCCR = 8;                   // Clock rate
}

void SPI_WriteEnable(void) {
    IOCLR0 = (1 << CS_PIN);        // Select device
    SPI_WriteByte(0x06);           // Write Enable command
    IOSET0 = (1 << CS_PIN);        // Deselect device
}

void SPI_WriteDisable(void) {
    IOCLR0 = (1 << CS_PIN);
    SPI_WriteByte(0x04);           // Write Disable command
    IOSET0 = (1 << CS_PIN);
}

void SPI_WriteByte(uint8_t byte) {
    S0SPDR = byte;
    while (!(S0SPSR & 0x80));      // Wait for transmission
}

uint8_t SPI_ReadByte(void) {
    S0SPDR = 0xFF;                 // Dummy write
    while (!(S0SPSR & 0x80));
    return S0SPDR;                 // Read received data
}

