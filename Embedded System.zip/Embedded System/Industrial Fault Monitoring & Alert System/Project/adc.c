#include "adc.h"
#include <LPC214x.h>

void Init_ADC(void) {
    PINSEL1 |= (1 << 24); // Configure P0.28 for ADC input
    AD0CR = (1 << 21) | (4 << 8); // Enable ADC, CLKDIV
}

float Read_ADC(uint8_t channel) {
    uint16_t result; // Declare at the start
    AD0CR = (AD0CR & ~(0xFF)) | (1 << channel); // Select channel
    AD0CR |= (1 << 24); // Start conversion
    while ((AD0GDR & (1U << 31)) == 0); // Wait for completion
    result = (AD0GDR >> 6) & 0x3FF; // Get result
    return (result * 3.3) / 1023.0; // Convert to voltage
}
